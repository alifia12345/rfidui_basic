<?php

    require "koneksidb.php";

        if ($_POST['Submit'] == "Submit") {
        $ambilrfid        = $_POST['rfid'];
        $saldo            = $_POST['saldoawal'];

        
        
    $datarfid = mysqli_query($koneksi, "SELECT * FROM tb_daftarrfid WHERE rfid = '$ambilrfid'");
    $rowrfid  = mysqli_fetch_array($datarfid);
    
    $tambahsaldo = $rowrfid['saldoawal'] + $saldo;
    
        //Masukan data ke Table
        $sqlsaldo = "UPDATE tb_daftarrfid SET saldoawal = '$tambahsaldo' WHERE rfid = '$ambilrfid'";
        $koneksi->query($sqlsaldo);

        header("Location: register.php?pesan=berhasil");
    }

?>